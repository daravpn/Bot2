import telebot
import os
import time
from telethon import TelegramClient, events, types
from typing import Tuple
from Crypto.Cipher import AES
from base64 import b64decode
from urllib.parse import unquote

tok="6011914153:AAHUdtuEM6Spdh5yHB2SrKtI8Ms-YNtGj9o" 
bot = telebot.TeleBot(tok)



def receive_telegram_message(message: telebot.types.Message) -> Tuple[str, str]:
    # mendapatkan username pengirim pesan
    username = message.from_user.username

    # mendapatkan teks pesan yang diterima
    pesan = message.text

    return (username, pesan)
    

@bot.message_handler(commands=['start']) 
def welcome(message):
    bot.send_message(message.chat.id, "WELLCOME TO BOT JOIN GRUP\n https://t.me/snifConfig\nhttps://t.me/EstebanUnlocker\nhttps://t.me/decrypt_vpn_file\nhttps://t.me/KMKZNET\n==========================")
    
@bot.message_handler(content_types=['document'])
def post(message):
    print(message)
    name=message.document.file_name
    id=message.document.file_id
    file_info = bot.get_file(id)
    print(file_info)
    downloaded_file = bot.download_file(file_info.file_path)
    jj=open(name,"wb")
    jj.write(downloaded_file)
    jj.close()
    os.system('python team.py "'+name+'" > test1.txt')
    os.system('node team.js "'+name+'" > test2.txt')
    jh1=open("test1.txt").read()
    jh2=open("test2.txt").read()
    bot.reply_to(message, "{} \n{}".format(jh1, jh2))

@bot.message_handler(func=lambda message: True)
def handle_all_message(message):
    if message.chat.type == "private":
        bot.reply_to(message, message.text)
    elif message.chat.type == "private":
        if('@Dectnl_bot' in message.text):
                        bot.reply_to(message, 'Pesan yang Anda kirimkan tidak valid.')
        
print('BOT BERJALAN')
print("JAGAN LUPA TURU") 
bot.polling() 

